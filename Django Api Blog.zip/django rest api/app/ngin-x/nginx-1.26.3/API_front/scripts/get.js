  // Fetch API data using JavaScript
  document.addEventListener("DOMContentLoaded", function () {
    fetchData();
});

async function fetchData() {
    try {
        // Show loading spinner
        document.getElementById('loading').style.display = 'block';

        // Call the API endpoint
        const response = await fetch('http://127.0.0.1:8000/posts/');
        const data = await response.json();

        // Hide loading spinner
        document.getElementById('loading').style.display = 'none';

        // Display data dynamically with animations
        const dataContainer = document.getElementById('dataContainer');
        data.forEach(post => {
            const postElement = document.createElement('div');
            postElement.classList.add('post');
            postElement.innerHTML = `
                <h2>${post.title}</h2>
                

                <a href="http://localhost:8080/blog_comment.html?id=${post.id}">Write & Read a Comment _ ${post.id} </a>
                <br>
                
                
            `;
            // Add some animation to each post
            

            dataContainer.appendChild(postElement);
        });
    } catch (error) {
        
    }
}

