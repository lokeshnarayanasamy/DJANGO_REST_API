 //blog comment write and read



 function getQueryParam(param) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(param);
}

// Get the 'id' from the URL and display it

const postId = getQueryParam('id');

document.addEventListener('DOMContentLoaded', function() {

const postTitle = document.getElementById('post-title');
const postContent = document.getElementById('post-content');
const commentsList = document.getElementById('comments-list');
const newCommentText = document.getElementById('new-comment-text');
const submitCommentBtn = document.getElementById('submit-comment');




fetch(`http://127.0.0.1:8000/posts/${postId}/`)
.then(response => response.json())
.then(data => {
postTitle.innerText="Title :"+" "+data.title;
postContent.innerText="Content :"+" "+data.content;

})
.catch();




// Fetch post details

fetch(`http://127.0.0.1:8000/posts/${postId}/comments/`)
.then(response => response.json())
.then(comments => {
commentsList.innerHTML = '';
comments.forEach(comment => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.innerHTML = `
        <div class="card-body">
            <p>${comment.content}</p>
            <p class="name">👤 ${comment.author}</p>
        </div>
    `;
    commentsList.appendChild(card);
    // Apply fade-in animation
    setTimeout(() => {
        card.style.opacity = 1;
        card.style.transition = 'opacity 0.5s ease';
    }, 100);
});
})
.catch(error => console.error('Error fetching data:', error));





});



// Add new comment


const apiUrl = `http://127.0.0.1:8000/posts/${postId}/comments/`;



document.getElementById('submitCommentBtn').addEventListener('click', function() {
const commentContent = document.getElementById('commentContent').value;

if (!commentContent) {
    document.getElementById('statusResult').textContent = "Please write a comment.";
    return;
}

// POST request to add a comment
fetch(apiUrl, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        
    },
    body: JSON.stringify({
        content: commentContent,
        
    })
})
.then(response => response.json())
.then(data => {
    if (data.ok) {
        document.getElementById('statusResult').textContent = "Comment added successfully!";
        
    } else {
        alert("Success: " + JSON.stringify(data));
        window.location.href = `http://localhost:8080/blog_comment.html?id=${post.id}`;
        
    }
})
.catch(error => {
    console.error('Error:', error);
    document.getElementById('statusResult').textContent = "An error occurred.";
});
});
