//Django rest Api



//Login Page Show Password

function togglePassword() {
    const passwordInput = document.getElementById("password");
    const eyeIcon = document.getElementById("eyeIcon");
    if (passwordInput.type === "password") {
      passwordInput.type = "text";
      eyeIcon.src = "https://img.icons8.com/ios-filled/50/ffffff/closed-eye.png";
    } else {
      passwordInput.type = "password";
      eyeIcon.src = "https://img.icons8.com/ios-filled/50/ffffff/visible.png";
    }
  }


  //Login page -- get access token

  function handleLogin(event) {
      event.preventDefault(); // stops form from reloading the page
      const username = document.getElementById("username").value;
      const password = document.getElementById("password").value;
      console.log("Username:", username);
      console.log("Password:", password);
      const CheckData = {
                      username,
                      password
                  };
      
      fetch('http://127.0.0.1:8000/api/token/', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(CheckData)
          })
      .then(res => res.json())
      .then(data => {
              if (data.access) {
                  // Save token in localStorage
                  localStorage.setItem('accessToken', data.access);
                  // Redirect to blog creation page
                  window.location.href = 'blog_create.html';
              } else {
                  alert('Login failed');
              }
          })
          .catch(err => {
              alert('Login error');
              console.error(err);
          });           

          
}






 
 




    
