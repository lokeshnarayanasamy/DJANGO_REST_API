// blog create page -- for create a blog
function Blog_posts(){
    const u_title = document.getElementById('title').value;
    const u_content = document.getElementById('content').value;
    const postdata = {
        title:u_title,
        content:u_content
    };
    const Result_Show = document.getElementById('Result');

    fetch('http://127.0.0.1:8000/posts/',{
        method:"POST",
        headers:{
            'Content-Type': 'application/json',
        },
        body:JSON.stringify( postdata )
    })
.then(response => response.json())

.then((data)=>{
  if(!data.ok){
    Result_Show.innerText="Blog Created Successfuly",
    window.location.href = '/blog_get_all/';
    
  }
})

.catch(
  Result_Show.innerText="pleace check Your Connection",
  Result_Show.style='color:red'
);
 }